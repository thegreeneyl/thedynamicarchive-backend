
Installation: Copy the folder „fizzi_for_uno“ to your arduino libraries folder.